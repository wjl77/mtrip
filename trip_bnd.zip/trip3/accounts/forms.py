import re

from django import forms
from django.contrib.auth import authenticate, login
from django.core.cache import cache
from django.db import transaction
from django.utils.timezone import now

from accounts.models import User, Profile


class LoginForm(forms.Form):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = None
    """ 登录表单 """
    username = forms.CharField(label='用户名',
                               max_length=100,
                               required=False,
                               help_text='使用帮助',
                               initial='admin')
    password = forms.CharField(label='密码', max_length=200, min_length=6,
                               widget=forms.PasswordInput)

    def clean_username(self):
        """ 验证用户名 hook 钩子函数 """
        username = self.cleaned_data['username']
        pattern = r'^1[0-9]{10}$'
        if not re.search(pattern, username):
            raise forms.ValidationError('手机号%s输入不正确',
                                        code='invalid_phone',
                                        params=(username, ))
        return username

    def clean(self):
        data = super().clean()
        # print(data)
        # 如果单个字段有错误，直接返回，不执行后面的验证
        if self.errors:
            return
        username = data.get('username', None)
        password = data.get('password', None)
        user = authenticate(username=username, password=password)
        if not user:
            raise forms.ValidationError('用户名或密码不正确')
        else:
            if not user.is_active:
                raise forms.ValidationError('该用户已被禁用')

        self.user = user
        return data

        # username = data.get('username', None)
        # password = data.get('password', None)
        # if username and password:
        #     # 查询用户名和密码匹配的用户
        #     user_list = User.objects.filter(username=username)
        #     err_list = []
        #     if user_list.count() == 0:
        #         err_list.append(forms.ValidationError('用户名不存在'))
        #         # raise forms.ValidationError('用户名不存在')
        #     # 验证密码是否正确
        #     # TODO 使用加密算法进行验证
        #     if not user_list.filter(password=password).exists():
        #         # raise forms.ValidationError('密码不正确')
        #         err_list.append(forms.ValidationError('密码不正确'))
        #     if err_list:
        #         raise forms.ValidationError(err_list)
        # return data

    def do_login(self, request):
        """ 执行用户登录 """
        user = self.user
        login(request, user)
        # 最后登录时间
        user.last_login = now()
        user.save()
        # 保存登录历史
        return user


class RegisterForm(forms.Form):

    username = forms.CharField(label='手机号',
                               max_length=16,
                               required=True,
                               error_messages={
                                   'required': '请输入手机号'
                               })

    password = forms.CharField(label='密码',
                               max_length=128,
                               required=True,
                               error_messages={
                                   'required': '请输入密码'
                               })

    nickname = forms.CharField(label='昵称',
                               max_length=16,
                               required=True,
                               error_messages={
                                   'required': '请输入昵称'
                               })

    sms_code = forms.CharField(label='短信验证码',
                               max_length=6,
                               required=True,
                               error_messages={
                                   'required': '请输入短信验证码'
                               })

    def clean_username(self):
        """ 验证用户名 hook 钩子函数 """
        username = self.cleaned_data['username']
        pattern = r'^1[0-9]{10}$'

        if not re.search(pattern, username):
            raise forms.ValidationError('手机号%s输入不正确',
                                        code='invalid_phone',
                                        params=(username, ))

        if User.objects.filter(username=username).exists():
            raise forms.ValidationError('该手机号已存在')

        return username

    def clean_nickname(self):
        """ 验证用户名 hook 钩子函数 """
        nickname = self.cleaned_data['nickname']

        if User.objects.filter(nickname=nickname).exists():
            raise forms.ValidationError('该昵称已存在')

        return nickname

    # def clean_sms_code(self):
    #
    #     sms_code = self.cleaned_data.get('sms_code', None)
    #     phone_num = self.cleaned_data.get('username', None)
    #
    #     if str(cache.get(phone_num)) != str(sms_code):
    #         raise forms.ValidationError('短信验证码错误或已失效')
    #
    #     return sms_code

    def clean(self):
        data = super().clean()
        if self.errors:
            return
        sms_code = self.cleaned_data.get('sms_code', None)
        phone_num = self.cleaned_data.get('username', None)

        if str(cache.get(phone_num)) != str(sms_code):
            raise forms.ValidationError('短信验证码错误或已失效')

        return data

    @transaction.atomic
    def do_register(self, request):
        username = self.cleaned_data['username']
        password = self.cleaned_data['password']
        nickname = self.cleaned_data['nickname']

        try:
            user = User.objects.create_user(
                username=username,
                password=password,
                nickname=nickname
            )

            profile = Profile.objects.create(
                user=user,
                username=user.username,
                version=request.headers.get('version', ''),
                source=request.headers.get('source', '')
            )

            login(request, user)

            user.last_login = now()
            user.save()
            # login history
            user.add_login_record(
                user=user,
                username=user.username,
                ip=request.META.get('REMOTE_ADDR'),
                version=request.headers.get('version', ''),
                source=request.headers.get('source', '')
            )
            return user, profile
        except Exception as e:
            print(e)
        return None

