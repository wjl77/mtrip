from django.urls import path

from accounts import views

urlpatterns = [
    # 用户登录表单
    path('user/login/', views.user_login, name='user_login'),
    path('user/info/', views.user_info, name='user_info'),
    path('user/logout/', views.user_logout, name='user_logout'),
    path('index/', views.index, name='index'),
    # 登录接口
    path('user/api/login/', views.user_api_login, name='user_api_login'),
    # 登出接口
    path('user/api/logout/', views.user_api_logout, name='user_api_logout'),
    # 用户详细信息接口
    path('user/api/info/', views.UserDetailInfo.as_view(), name='user_api_info'),
    # 注册接口
    path('user/api/register/', views.UserRegisterView.as_view(), name='user_api_register')
]