from system.serializers import BaseImageSerializer
from utils.serializers import BaseListPageSerializer, BaseSerializer


class SightListSerializer(BaseListPageSerializer):

    def get_object(self, obj):
        return {
            'id': obj.id,
            'name': obj.name,
            'main_img': obj.main_img.url,
            'score': obj.score,
            'min_price': obj.min_price,
            'province': obj.province,
            'city': obj.city,
            'comment_people_count': obj.comment_count
        }


class SightDetailSerializer(BaseSerializer):

    def to_dict(self):
        obj = self.obj
        return {
            'id': obj.id,
            'name': obj.name,
            'desc': obj.desc,
            'img': obj.banner_img.url,
            'content': obj.content,
            'score': obj.score,
            'min_price': obj.min_price,
            'province': obj.province,
            'city': obj.city,
            'area': obj.area,
            'town': obj.town,
            'comment_people_count': obj.comment_count,
            'image_count': obj.image_count
        }


class CommentListSerializer(BaseListPageSerializer):

    def get_object(self, obj):
        images = []

        for image in obj.images.filter(is_valid=True):
            images.append(BaseImageSerializer(image).to_dict())

        return {
            'user': {
                'pk': obj.user.id,
                'nickname': obj.user.nickname
            },
            'pk': obj.id,
            'content': obj.content,
            'is_top': obj.is_top,
            'love_count': obj.love_count,
            'score': obj.score,
            'is_public': obj.is_public,
            'images': images,
            'created_at': obj.created_at.strftime('%Y-%m-%d')
        }


class TicketListSerializer(BaseListPageSerializer):
    def get_object(self, obj):
        return {
            'pk': obj.pk,
            'name': obj.name,
            'desc': obj.desc,
            'types': obj.types,
            'price': obj.price,
            'discount': obj.discount,
            'total_stock': obj.total_stock,
            'remain_stock': obj.remain_stock,
            'sell_price': obj.sell_price
        }


class SightInfoDetailSerializer(BaseSerializer):

    def to_dict(self):
        obj = self.obj
        return {
            'pk': obj.sight.pk,
            'entry_explain': obj.entry_explain,
            'play_way': obj.play_way,
            'tips': obj.tips,
            'traffic': obj.traffic
        }


class TicketDetailSerializer(BaseSerializer):

    def to_dict(self):
        obj = self.obj
        return {
            'pk': obj.pk,
            'name': obj.name,
            'desc': obj.desc,
            'types': obj.types,
            'price': obj.price,
            'sell_price': obj.sell_price,
            'discount': obj.discount,
            'expire_date': obj.expire_date,
            'return_policy': obj.return_policy,
            'has_invoice': obj.has_invoice,
            'entry_way': obj.get_entry_way_display(),
            'tips': obj.tips,
            'remark': obj.remark
        }





