import json

from django.db import transaction
from django.db.models import F, Q
from django.http import JsonResponse, HttpResponse
from django.utils.decorators import method_decorator
from django.views.generic import FormView, ListView
from django.views.generic.detail import BaseDetailView

from order.choices import OrderStatus
from order.forms import SubmitTicketOrderForm
from order.models import Order
from order.serializers import OrderDetailSerializer, OrderListSerializer
from sight.models import Ticket
from utils.response import BadRequestJsonResponse, NotFoundJsonResponse
from utils.views import login_required


@method_decorator(login_required, name='dispatch')
class SubmitOrderView(FormView):
    """ 填写并提交订单的接口 """
    form_class = SubmitTicketOrderForm

    http_method_names = ['post']

    def form_valid(self, form):
        user = self.request.user
        obj = form.save(user)

        return JsonResponse({
            'sn': obj.sn
        }, status=201)

    def form_invalid(self, form):
        err = json.loads(form.errors.as_json())
        print(err)
        return BadRequestJsonResponse(err)


@method_decorator(login_required, name='dispatch')
class OrderDetail(BaseDetailView):
    slug_field = 'sn'
    slug_url_kwarg = 'sn'

    def get_queryset(self):
        # 当前用户，对应的订单列表，查询出来
        user = self.request.user
        queryset = Order.objects.filter(user=user, is_valid=True)
        return queryset

    def get(self, request, *args, **kwargs):
        """ 重写get方法, get请求，查询订单详情"""
        # get_object, 根据url的sn，到queryset查找对应sn的记录
        order_obj = self.get_object()
        data = OrderDetailSerializer(order_obj).to_dict()
        return JsonResponse(data)

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """ 支付 """
        order_obj = self.get_object()
        if order_obj.status == OrderStatus.SUBMIT:
            order_obj.status = OrderStatus.PAID
            order_obj.save()
            order_obj.order_items.update(status=OrderStatus.PAID)
            return HttpResponse('', status=201)
        return HttpResponse('', status=200)

    @transaction.atomic
    def delete(self, request, *args, **kwargs):
        """ 逻辑删除订单  已支付，已取消， 才可以删除 """
        order_obj = self.get_object()
        if order_obj.status == OrderStatus.PAID or order_obj.status == OrderStatus.CANCELED:
            if order_obj.is_valid:
                order_obj.is_valid = False
                order_obj.save()
                order_obj.order_items.update(is_valid=False)
                return HttpResponse('', status=201)
        return HttpResponse('', status=200)

    @transaction.atomic
    def put(self, request, *args, **kwargs):
        """ 取消订单 """
        order_obj = self.get_object()
        if order_obj.status == OrderStatus.SUBMIT:
            order_obj.status = OrderStatus.CANCELED
            order_obj.save()
            items = order_obj.order_items.filter(status=OrderStatus.SUBMIT)
            # 加回已扣减的库存
            for item in items:
                ticket_obj = item.content_object
                ticket_obj.remain_stock = F('remain_stock') + item.count
                ticket_obj.save()

            items.update(status=OrderStatus.CANCELED)

            return HttpResponse('', status=201)
        return HttpResponse('', status=200)


@method_decorator(login_required, name='dispatch')
class OrderListView(ListView):
    paginate_by = 20

    def get_queryset(self):
        user = self.request.user
        query = Q(is_valid=True, user=user)
        status = self.request.GET.get('status', None)

        if status and status != '0':
            query = query & Q(status=status)

        queryset = Order.objects.filter(query)
        return queryset

    def render_to_response(self, context, **response_kwargs):
        page_pbj = context['page_obj']
        if page_pbj:
            data = OrderListSerializer(page_pbj).to_dict()
            return JsonResponse(data)
        return NotFoundJsonResponse()

    def get_paginate_by(self, queryset):
        page_size = self.request.GET.get('limit', None)
        return page_size or self.paginate_by

