from django.apps import AppConfig


class MasterConfig(AppConfig):
    name = 'master'
