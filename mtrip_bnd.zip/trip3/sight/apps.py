from django.apps import AppConfig


class SightConfig(AppConfig):
    name = 'sight'
    verbose_name = '景点及门票管理'
