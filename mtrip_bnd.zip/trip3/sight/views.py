import json

from django.core.cache import cache
from django.db.models import Q, F
from django.http import JsonResponse, HttpResponse
from django.template.defaulttags import comment
from django.utils.decorators import method_decorator
from django.views.generic import ListView, DetailView

from sight.models import Sight, Comment, Ticket, Info, SightCollection
from sight.serializers import SightListSerializer, SightDetailSerializer, CommentListSerializer, TicketListSerializer, \
    SightInfoDetailSerializer, TicketDetailSerializer
from utils.response import NotFoundJsonResponse
from utils.views import login_required


class SightListView(ListView):
    page_kwarg = 'page'
    paginate_by = 5

    def get_queryset(self):
        """ 查询结果集 """
        query = Q(is_valid=True)

        is_hot = self.request.GET.get('is_hot', None)
        if is_hot:
            query = query & Q(is_hot=True)

        is_top = self.request.GET.get('is_top', None)
        if is_top:
            query = query & Q(is_top=True)

        # 景点名称搜索
        name = self.request.GET.get('name', None)
        if name:
            query = query & Q(name__icontains=name)

        queryset = Sight.objects.filter(query)
        return queryset

    def render_to_response(self, context, **response_kwargs):
        page_obj = context['page_obj']

        if page_obj:
            data = SightListSerializer(page_obj).to_dict()
            return JsonResponse(data)
        return NotFoundJsonResponse()

        # data = {
        #     'meta': {
        #         'current_page': page_obj.number,
        #         'total_page': page_obj.paginator.num_pages,
        #         'total_count': page_obj.paginator.count
        #     },
        #     'objects': []
        # }
        # for item in page_obj.object_list:
        #     data['objects'].append({
        #         'id': item.id,
        #         'name': item.name,
        #         'main_img': item.main_img.url,
        #         'score': item.score,
        #         'min_price': item.min_price,
        #         'province': item.province,
        #         'city': item.city,
        #         'comment_people_count': 0
        #     })
        # return JsonResponse(data)


class SightDetailView(DetailView):

    def get_queryset(self):
        queryset = Sight.objects.all()
        return queryset

    def render_to_response(self, context, **response_kwargs):
        obj = context['object']
        if obj:
            if obj.is_valid == False:
                return NotFoundJsonResponse()
            data = SightDetailSerializer(obj).to_dict()
            return JsonResponse(data)
        return NotFoundJsonResponse()


class SightCommentListView(ListView):
    paginate_by = 10

    def get_queryset(self):
        sight_id = self.kwargs.get('pk', None)
        if sight_id:
            sight = Sight.objects.filter(pk=sight_id, is_valid=True).first()
            return sight.comments.filter(is_valid=True)
        return Comment.objects.none()

    def render_to_response(self, context, **response_kwargs):
        page_obj = context['page_obj']
        if page_obj:
            data = CommentListSerializer(page_obj).to_dict()
            return JsonResponse(data)
        return NotFoundJsonResponse()


class SightTicketListView(ListView):
    paginate_by = 10

    def get_queryset(self):
        sight_id = self.kwargs.get('pk', None)
        if sight_id:
            ticket_list_queryset = Ticket.objects.filter(sight_id=sight_id, is_valid=True)
            return ticket_list_queryset
        return Ticket.objects.none()

    def render_to_response(self, context, **response_kwargs):
        page_obj = context['page_obj']
        if page_obj:
            data = TicketListSerializer(page_obj).to_dict()
            return JsonResponse(data)
        return NotFoundJsonResponse()


class SightInfoDetailView(DetailView):
    slug_field = 'sight__pk'

    def get_queryset(self):
        queryset = Info.objects.all()
        return queryset

    def render_to_response(self, context, **response_kwargs):
        obj = context['object']
        if obj:
            data = SightInfoDetailSerializer(obj).to_dict()
            return JsonResponse(data)
        return NotFoundJsonResponse()


class SightImageListView(ListView):
    paginate_by = 10

    def get_queryset(self):
        sight_id = self.kwargs.get('pk', None)
        if sight_id:
            sight = Sight.objects.filter(is_valid=True, id=sight_id).first()
            return sight.images.filter(is_valid=True)
        return Sight.objects.none()

    def render_to_response(self, context, **response_kwargs):
        page_obj = context['page_obj']

        if page_obj:
            data = {
                'meta': {
                    'current_page': page_obj.number,
                    'total_page': page_obj.paginator.num_pages,
                    'total_count': page_obj.paginator.count
                },
                'objects': []
            }
            for item in page_obj.object_list:
                data['objects'].append({
                    'img': item.img.url,
                    'summary': item.summary
                })
            return JsonResponse(data)
        return NotFoundJsonResponse()


class TicketDetailView(DetailView):

    def get_queryset(self):
        queryset = Ticket.objects.filter(is_valid=True)
        return queryset

    def render_to_response(self, context, **response_kwargs):
        obj = context['object']
        if obj:
            data = TicketDetailSerializer(obj).to_dict()
            return JsonResponse(data)
        return NotFoundJsonResponse()


def collect_sight(request):
    """ 收藏/取消收藏/收藏人数 接口 """
    if request.method == 'POST':
        user = request.POST.get('userId')
        sight = request.POST.get('sightId')
        is_collect = True if request.POST.get('isCollect') == 'true' else False

        collection = SightCollection.objects.filter(user_id=user, sight_id=sight).first()

        if not collection:
            collection = SightCollection.objects.create(user_id=user, sight_id=sight)
        else:
            if is_collect:
                collection.is_valid = is_collect
            else:
                collection.is_valid = is_collect
            collection.save()

        collect_count = SightCollection.objects.filter(sight_id=sight, is_valid=True).count()

        data = {
            'userId': collection.user_id,
            'sightId': collection.sight_id,
            'isCollect': collection.is_valid,
            'collectCount': collect_count
        }
        return JsonResponse(data)

    user = int(request.GET.get('userId'))
    sight = int(request.GET.get('sightId'))
    collection = SightCollection.objects.filter(user_id=user, sight_id=sight).first()
    if not collection:
        collection = SightCollection.objects.create(user_id=user,
                                                    sight_id=sight,
                                                    is_valid=False)

    collect_count = SightCollection.objects.filter(sight_id=sight, is_valid=True).count()

    data = {
        'userId': collection.user_id,
        'sightId': collection.sight_id,
        'isCollect': collection.is_valid,
        'collectCount': collect_count
    }
    return JsonResponse(data)


@method_decorator(login_required, name='dispatch')
class CollectionListView(ListView):
    """ 收藏列表接口 """
    paginate_by = 10

    def get_queryset(self):
        user = self.request.user
        queryset = SightCollection.objects.filter(
            user=user, is_valid=True).order_by('-updated_at')
        return queryset

    def render_to_response(self, context, **response_kwargs):
        page_obj = context['page_obj']

        if page_obj:
            data = {
                'meta': {
                    'current_page': page_obj.number,
                    'total_page': page_obj.paginator.num_pages,
                    'total_count': page_obj.paginator.count
                },
                'objects': []
            }
            for item in page_obj.object_list:
                data['objects'].append({
                    'id': item.sight.id,
                    'name': item.sight.name,
                    'main_img': item.sight.main_img.url,
                    'score': item.sight.score
                })
            return JsonResponse(data)
        return NotFoundJsonResponse()


class SightListCacheView(ListView):
    """ 缓存优化 """
    page_kwarg = 'page'
    paginate_by = 20

    def get_queryset(self):
        """ 查询结果集 """
        query = Q(is_valid=True)

        is_hot = self.request.GET.get('is_hot', None)
        if is_hot:
            query = query & Q(is_hot=True)

        is_top = self.request.GET.get('is_top', None)
        if is_top:
            query = query & Q(is_top=True)

        # 景点名称搜索
        # name = self.request.GET.get('name', None)
        # if name:
        #     query = query & Q(name__icontains=name)

        queryset = Sight.objects.filter(query)
        return queryset

    def render_to_response(self, context, **response_kwargs):
        is_hot = self.request.GET.get('is_hot', None)
        if is_hot:
            try:
                data = cache.get('index_hot')
                if data:
                    # print(data)
                    return JsonResponse(json.loads(data))
            except Exception as e:
                print(e)

        is_top = self.request.GET.get('is_top', None)
        if is_top:
            try:
                data = cache.get('index_top')
                if data:
                    # print(data)
                    return JsonResponse(json.loads(data))
            except Exception as e:
                print(e)
        # sql拿数据
        page_obj = context['page_obj']

        if page_obj:
            data = SightListSerializer(page_obj).to_dict()
            return JsonResponse(data)
        return NotFoundJsonResponse()









