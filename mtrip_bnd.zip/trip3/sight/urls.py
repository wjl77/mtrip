from django.urls import path

from sight import views

urlpatterns = [
    # 景点列表分页接口
    path('sight/list/', views.SightListView.as_view(), name='sight_list'),
    # 首页缓存
    path('sight/list/cache/', views.SightListCacheView.as_view(), name='sight_list_cache'),
    # 景点详情接口
    path('sight/detail/<int:pk>/', views.SightDetailView.as_view(), name='sight_detail'),
    # 景点评论列表接口
    path('comment/list/<int:pk>/', views.SightCommentListView.as_view(), name='sight_comment_list'),
    # 景点门票列表接口
    path('ticket/list/<int:pk>/', views.SightTicketListView.as_view(), name='sight_ticket_list'),
    # 景点介绍的接口
    path('sight/info/<int:pk>/', views.SightInfoDetailView.as_view(), name='sight_info'),
    # 景点图片列表的接口
    path('image/list/<int:pk>/', views.SightImageListView.as_view(), name='sight_image_list'),
    # 景点门票详情的接口
    path('ticket/detail/<int:pk>/', views.TicketDetailView.as_view(), name='ticket_detail'),
    # 收藏景点
    path('collect/', views.collect_sight, name='collect_sight'),
    # 收藏列表
    path('collect/list/', views.CollectionListView.as_view(), name='collection_list')
]
