import json

from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from django.views import View
from django.views.generic import FormView

from accounts.forms import LoginForm, RegisterForm
from accounts.serializers import UserSerializer, UserProfileSerializer
from utils.response import BadRequestJsonResponse, MethodNotAllowedJsonResponse, UnauthorizedJsonResponse, \
    ServerErrorJsonResponse


def user_login(request):
    """ 用户登录 """
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            form.do_login(request)
            return redirect('user_info')
        else:
            print(form.errors)
    else:
        form = LoginForm()
    return render(request, 'user_login.html', {
        'form': form
    })


@login_required
def user_info(request):
    """ 用户信息 """
    user = request.user
    return render(request, 'user_info.html', {
        'user': user
    })


def user_logout(request):
    logout(request)
    return redirect('index')


def index(request):
    return render(request, 'index.html')


def user_api_login(request):
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            user = form.do_login(request)
            data = {
                'user': UserSerializer(user).to_dict(),
                'profile': UserProfileSerializer(user.profile).to_dict()
            }
            return JsonResponse(data)
        else:
            err = json.loads(form.errors.as_json())
            return BadRequestJsonResponse(err)
    else:
        return MethodNotAllowedJsonResponse()


def user_api_logout(request):
    logout(request)
    return HttpResponse(status=201)


class UserDetailInfo(View):

    def get(self, request):
        """ get请求 """
        user = request.user
        if not user.is_authenticated:
            return UnauthorizedJsonResponse()
        profile = user.profile
        data = {
            'user': UserSerializer(user).to_dict(),
            'profile': UserProfileSerializer(profile).to_dict()
        }
        return JsonResponse(data)


class UserRegisterView(FormView):

    form_class = RegisterForm
    http_method_names = ['post']

    def form_valid(self, form):
        data = form.do_register(request=self.request)

        if not data:
            return ServerErrorJsonResponse()

        user, profile = data
        returned_data = {
            'user': UserSerializer(user).to_dict(),
            'profile': UserProfileSerializer(profile).to_dict()
        }
        return JsonResponse(returned_data, status=201)

    def form_invalid(self, form):
        # print('Errors:', form.errors)
        err = json.loads(form.errors.as_json())
        return BadRequestJsonResponse(err)

