from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from accounts.models import Profile, User


@admin.register(User)
class MyUserAdmin(UserAdmin):
    list_display = ('username', 'nickname', 'is_active', 'is_staff', 'date_joined')
    search_fields = ('username', 'nickname')
    # 新增
    add_fieldsets = UserAdmin.add_fieldsets + ((None, {'fields': ('nickname', )}), )
    # 修改
    fieldsets = UserAdmin.fieldsets + ((None, {'fields': ('nickname', 'avatar')}), )

    actions = ['disable_user', 'enable_user']

    def disable_user(self, request, queryset):
        queryset.update(is_active=False)

    def enable_user(self, request, queryset):
        queryset.update(is_active=True)

    disable_user.short_description = '批量禁用用户'
    enable_user.short_description = '批量启用用户'


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('format_username', 'sex', 'age', 'created_at')
    list_per_page = 5
    list_select_related = ('user', )
    list_filter = ('sex', )
    search_fields = ('username', 'user__nickname')

    def format_username(self, obj):
        return obj.username[:3] + '****' + obj.username[-4:]

    format_username.short_description = '用户名'