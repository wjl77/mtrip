from utils.serializers import BaseSerializer


class UserSerializer(BaseSerializer):
    def to_dict(self):
        obj = self.obj
        return {
            'pk': obj.pk,
            'username': obj.username,
            'nickname': obj.nickname,
            'avatar': obj.avatar.url if obj.avatar else ''
        }


class UserProfileSerializer(BaseSerializer):
    def to_dict(self):
        obj = self.obj
        return {
            'real_name': obj.real_name,
            'sex': obj.sex,
            'sex_display': obj.get_sex_display()
        }
