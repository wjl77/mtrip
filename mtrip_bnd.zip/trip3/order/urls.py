from django.urls import path

from order import views

urlpatterns = [
    # 填写/提交订单的接口
    path('submit/order/', views.SubmitOrderView.as_view(), name='ticket_submit'),
    # 提交订单后，根据订单号的订单详情接口 查询 支付 取消 删除
    path('order/detail/<int:sn>/', views.OrderDetail.as_view(), name='order_detail'),
    # 订单列表的接口
    path('order/list/', views.OrderListView.as_view(), name='order_list')
]
